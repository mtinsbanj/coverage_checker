<div>
  <?php if (isset($component)) { $__componentOriginald5d051f243b37508d39f8ce3d92a5684 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5d051f243b37508d39f8ce3d92a5684 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5d051f243b37508d39f8ce3d92a5684)): ?>
<?php $attributes = $__attributesOriginald5d051f243b37508d39f8ce3d92a5684; ?>
<?php unset($__attributesOriginald5d051f243b37508d39f8ce3d92a5684); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5d051f243b37508d39f8ce3d92a5684)): ?>
<?php $component = $__componentOriginald5d051f243b37508d39f8ce3d92a5684; ?>
<?php unset($__componentOriginald5d051f243b37508d39f8ce3d92a5684); ?>
<?php endif; ?>
  <div class="intro">
    <img src="img/coverage_bg.png" alt="" class="cover_img">
    <div class="mask d-flex align-items-center h-100">
      <div class="container main-content">
        <div class="row justify-content-center">
          <div class="col-md-12 logo">
            <img src="img/logo.png" class="img-responsive" alt="fob logo">
          </div>
          <div class="col-xl-7 col-md-8">
            <form class="bg-white rounded-5 shadow-5-strong px-5 pb-5 pt-3">
              <!-- Session Messages -->
              <div>
                <?php if(session()->has('thankyou_message')): ?>
                  <div class="alert alert-primary" role="alert">
                    <?php echo e(session('thankyou_message')); ?>

                  </div>
                  <hr />
                <?php endif; ?>

                <?php if(session()->has('message')): ?>
                  <div class="alert alert-primary" role="alert">
                    <?php echo e(session('message')); ?>

                  </div>
                <?php endif; ?>

                <?php if(session()->has('success_message')): ?>
                  <div class="gif_success">
                    <img src="img/success_animation.gif" class="img-responsive">
                  </div>
                  <div class="alert alert-success" role="alert">
                    <?php echo session('success_message'); ?>

                  </div>
                <?php endif; ?>

                <?php if(session()->has('survey_message')): ?>
                  <div class="alert alert-warning" role="alert">
                    <?php echo session('survey_message'); ?>

                  </div>
                <?php endif; ?>

                <?php if(session()->has('failed_message')): ?>
                  <div class="alert alert-danger" role="alert">
                    <?php echo e(session('failed_message')); ?>

                  </div>
                <?php endif; ?>
              </div>

              <!-- Address Input -->
              <?php if(!$isSubmitted): ?>
              <div class="form-outline mb-4">
                <label class="form-label">Enter Address</label>
                <input type="text" wire:model.debounce.150ms="address" 
                       class="form-control" placeholder="Insert full address" />
              </div>
              <?php endif; ?>

              <!-- Location Selection -->
              <?php if($isLocated): ?>
              <div class="form-outline mb-4">
                <label class="form-label">Choose Your Specific Location</label>
                <select wire:model="selectedaddress" class="form-control">
                  <option value="">---SELECT LOCATION---</option>
                  <?php $__currentLoopData = $geoAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($add['geometry']['location']['lat'].'-'.$add['geometry']['location']['lng']); ?>">
                    <?php echo e($add['formatted_address']); ?>

                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
              </div>
              <?php endif; ?>

              <!-- Action Buttons -->
              <div class="button-group">
                <?php if(!$isLocated): ?>
                <button wire:click="convertAddress" type="button" 
                        class="btn btn-primary btn-block">Continue</button>
                <?php endif; ?>

                <?php if($isLocated): ?>
                  <?php if(!session()->has('success_message')): ?>
                  <button wire:click="location" type="button" 
                          class="btn btn-primary btn-block">Confirm Coverage</button>
                  <?php endif; ?>

                  <?php if(session()->has('success_message')): ?>
                  <a href="https://fob.ng/buy-now-lagos" type="button" 
                     class="btn btn-primary btn-block" target="_blank">Buy Now</a>
                  <?php endif; ?>
                <?php endif; ?>
              </div>

              <!-- Additional Options -->
              <div class="row form_details">
                <?php if(session()->has('message') || session()->has('success_message') || 
                     session()->has('survey_message') || session()->has('failed_message')): ?>
                <div class="col-md-9 mt-3">
                  <div class="left_details">
                    <button type="button" data-toggle="modal" 
                            data-target="#userInfoModal">Let Us Contact You</button>
                  </div>
                </div>
                <?php endif; ?>
                
                <?php if($isLocated): ?>
                <div class="col-md-3 mt-3">
                  <div class="right_details">
                    <button wire:click="refresh" type="button">
                      <i class="fa fa-refresh"></i> Restart
                    </button>
                  </div>
                </div>
                <?php endif; ?>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Contact Modal -->
  <div class="modal fade" id="userInfoModal" tabindex="-1" role="dialog" 
       aria-labelledby="userInfoModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Enter Your Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form wire:submit.prevent="storeContact">
          <div class="modal-body">
            <?php if($errorMessage != ''): ?>
            <div class="alert alert-danger" role="alert">
              <?php echo e($errorMessage); ?>

            </div>
            <?php endif; ?>
            
            <div class="form-row">
              <!-- Form fields remain the same -->
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\coverage\resources\views/livewire/home.blade.php ENDPATH**/ ?>