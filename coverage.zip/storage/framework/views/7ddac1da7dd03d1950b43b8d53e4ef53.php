<div wire:loading.delay wire:target="location,convertAddress,storeContact">
  <div class="loading_spinner">
    <div class="la-ball-pulse-sync" style="color: #fff;">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\coverage\resources\views/components/loader.blade.php ENDPATH**/ ?>