<?php
//file : app/config/constants.php

return [
	'POSITIONSTACK_API_KEY' => '49508a6623d8ab3af6d2c2e0e19a070e',
	'POSITIONSTACK_API' => 'http://api.positionstack.com/v1/forward?access_key=',

	'LOCATIONIQ_API_KEY' => 'pk.9478642e6b3c4e5907f3bdecc79bf594',
	'LOCATIONIQ_API' => 'https://us1.locationiq.com/v1/search?key=',

	'HERE_API_KEY' => 'ZkfbnfhKPKr-MRoI1qyyIkENnneSzbyDNseIVMnZnFg',
	'HERE_API' => 'https://geocode.search.hereapi.com/v1/geocode?q=',


	'GOOGLE_GEO_API' => 'https://maps.googleapis.com/maps/api/geocode/json?',
	// 'GOOGLE_API_KEY' => 'AIzaSyCvxKeZON2z3FqFRHOjzWJZglJR-5B9Jx0'
	'GOOGLE_API_KEY' => 'AIzaSyB2n6XRcZTQyQKG6W52oXEi4GitTGx9Npc'

];